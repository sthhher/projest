
class Model:
    
    def __init__(self, model_identifier):
        self.model_identifier = {}

    def __str__(self):
        return "%s" %(self.model_identifier)