
class Chain:
    
    def __init__(self, chain_identifier):
        self.chain_identifier = chain_identifier
        
    def __str__(self):
        return "%s" %(self.chain_identifier)